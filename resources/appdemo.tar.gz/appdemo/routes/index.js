var express = require('express');
var router = express.Router();

/* Get register page */
router.get('/register', function(req, res, next) {
  if (req.session.user) {
    res.render('cluster', { title: 'cluster'});
    return;
  }
  res.render('register', { title: 'register' });
});

/* Post register page */
router.post('/register', function(req, res, next) {
  if (req.session.user) {
    res.render('cluster', { title: 'cluster'});
    return;
  }
  res.redirect('/login');
});

/* Get home page. */
router.get('/', function(req, res, next) {
  if (req.session.user) {
    res.render('cluster', { title: 'cluster'});
    return;
  }
  res.render('login', { title: 'login' });
});

/* Get login page */
router.get('/login', function(req, res, next) {
  if (req.session.user) {
    res.render('cluster', { title: 'cluster'});
    return;
  }
  res.render('login', { title: 'login' });
});

/* Post login page */
router.post('/login', function(req, res, next) {
  var user={
    userid:'admin',
    password:'admin'
  }
  if(req.body.userid===user.userid && req.body.password===user.password){
    req.session.user=user;
    res.redirect('/cluster');
    return;
  }
  res.redirect('/login');
});

/* Get logout page */
router.get('/logout', function(req, res, next) {
  req.session.user=null;
  res.redirect('/');
});

/* Get cluster page */
router.get('/cluster', function(req, res, next) {
  if (req.session.user) {
    res.render('cluster', { title: 'cluster'});
    return;
  }
  res.redirect('/login');
});

module.exports = router;

